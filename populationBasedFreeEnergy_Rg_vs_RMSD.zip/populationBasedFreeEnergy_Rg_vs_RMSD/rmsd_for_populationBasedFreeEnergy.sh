#!/bin/bash
#SBATCH -J job
#SBATCH -o output.slurm.out
#SBATCH --mem=64G
#SBATCH --cpus-per-task=32
#SBATCH --time=1-10:00:00
conda activate ambertools
###
sim="<prefix>"
for rep in "r01" "r02" "r03" "r04";
do
cpptraj << EOF
parm <path>_${rep}_unwrapped.prmtop
trajin <path>_${rep}_unwrapped.nc 1 20000
parm <starting stucture parm>.prmtop [reftop]
reference <starting structure>.rst7 parm [reftop] [struct0]
rms allTR (:1-1343)&(@CA) ref [struct0] out rmsd_all_${sim}_${rep}_for2d.dat
run
EOF
done
###
