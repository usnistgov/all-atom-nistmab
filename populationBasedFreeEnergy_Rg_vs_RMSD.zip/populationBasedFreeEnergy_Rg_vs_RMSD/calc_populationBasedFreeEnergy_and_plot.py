"""2D Pseudo-Free Energy Surface: RMSD vs. Rg with K-means Overlays

Aggregates all replicates per condition, performs Boltzmann reweighting
"""

import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np

# ==============================================================================
# 1. CONFIGURATION & THERMODYNAMIC PARAMETERS
# ==============================================================================
prefixes = ["<prefix1>", "<prefix2>"]
replicates = ["r01", "r02", "r03", "r04"]

# Bin resolution (in Angstroms)
bin_width_rmsd = 0.5
bin_width_rg = 0.5

# Thermodynamic constants
temperature = 298.0  # Simulation temperature in Kelvin
R_gas = 8.314462618e-3  # Universal gas constant in kJ / (mol * K)
kBT = R_gas * temperature  # Thermal energy (~2.478 kJ/mol at 298 K)

# Energy cutoff for visualization (in kJ/mol; 20 kJ/mol ~= 4.78 kcal/mol)
max_dG_kJ = 20.5
KJ_TO_KCAL = 1.0 / 4.184

# Non-linear color stretching:
# gamma < 1.0 allocates more colormap palette space to lower values.
# (0.5 = square root; lower = more dramatic low-energy contrast)
gamma_fes = 0.5

# Base colormap: 'viridis_r' or 'turbo_r'
base_cmap_name = "viridis_r"

# K-means 9-frame color palette (Frame 0 to 8)
kmeans_colors = [
    "black",
    "red",
    "darkgreen",
    "blue",
    "orange",
    "brown",
    "gray",
    "violet",
    "cyan",
]

# Plot aesthetics & font sizes
x_label = r"RMSD ($\mathrm{\AA}$)"
y_label = r"Radius of Gyration ($\mathrm{\AA}$)"

font_size_title = 14
font_size_axes_labels = 14
font_size_ticks = 12
font_size_legend = 11
font_size_cbar_label = 13
kmeans_marker_size = 70

# Offset to position legend cleanly to the right of the dual colorbar
legend_x_offset = 1.35

# ==============================================================================
# BUILD RESAMPLED COLORMAP (Dramatic low-energy contrast + linear axis)
# ==============================================================================
base_cmap = plt.get_cmap(base_cmap_name)
resampled_vals = np.linspace(0.0, 1.0, 256) ** gamma_fes
custom_cmap = mcolors.ListedColormap(base_cmap(resampled_vals))
custom_cmap.set_bad(color="white")


# ==============================================================================
# 2. DATA LOADING & GLOBAL BOUNDS DETERMINATION
# ==============================================================================
def load_data_safe(prefix, rep):
  """Loads RMSD and Rg data; skips cleanly if file is missing."""
  rmsd_file = f"rmsd_all_{prefix}_{rep}_for2d.dat"
  rg_file = f"rg_{prefix}_{rep}_for2d.dat"
  try:
    rmsd_data = np.loadtxt(rmsd_file, comments="#")[:, 1]
    rg_data = np.loadtxt(rg_file, comments="#")[:, 1]
    return rmsd_data, rg_data
  except Exception:
    return None, None


# Load prefix-specific K-means centroids
kmeans_data = {}
for p in prefixes:
  try:
    k_rmsd = np.loadtxt(f"rmsd_{p}_9kmeans.dat", comments="#")[:, 1]
    k_rg = np.loadtxt(f"rg_{p}_9kmeans.dat", comments="#")[:, 1]
    kmeans_data[p] = (k_rmsd, k_rg)
  except Exception as e:
    raise FileNotFoundError(
        f"Failed to load kmeans data files for prefix {p}: {e}"
    )

# Scan all replicate files and K-means points to enforce identical grid boundaries
all_data = {}
global_rmsd_list = []
global_rg_list = []

for p in prefixes:
  for r in replicates:
    rmsd, rg = load_data_safe(p, r)
    if rmsd is not None:
      all_data[(p, r)] = (rmsd, rg)
      global_rmsd_list.append(rmsd)
      global_rg_list.append(rg)

if not global_rmsd_list:
  raise FileNotFoundError("No trajectory data files found.")

all_kmeans_rmsd = [data[0] for data in kmeans_data.values()]
all_kmeans_rg = [data[1] for data in kmeans_data.values()]

all_rmsd_concat = np.concatenate(global_rmsd_list + all_kmeans_rmsd)
all_rg_concat = np.concatenate(global_rg_list + all_kmeans_rg)
g_xlim = (np.floor(all_rmsd_concat.min()), np.ceil(all_rmsd_concat.max()))
g_ylim = (np.floor(all_rg_concat.min()), np.ceil(all_rg_concat.max()))

# Construct uniform 2D bins
bins_x = np.arange(g_xlim[0], g_xlim[1] + bin_width_rmsd, bin_width_rmsd)
bins_y = np.arange(g_ylim[0], g_ylim[1] + bin_width_rg, bin_width_rg)


# ==============================================================================
# 3. BOLTZMANN REWEIGHTING & PLOTTING FUNCTIONS
# ==============================================================================
def counts_to_free_energy(counts, kbt_val):
  """Converts 2D histogram bin counts into pseudo-free energy in kJ/mol.

  ΔG(x, y) = -kB * T * ln( counts / counts_max )
  """
  counts_masked = np.where(counts > 0, counts.astype(float), np.nan)
  max_count = np.nanmax(counts_masked)
  dG = -kbt_val * np.log(counts_masked / max_count)
  return dG


def save_fes_with_kmeans(x, y, k_rmsd, k_rg, title, filename):
  """Computes 2D pseudo-FES, plots with linear dual-axis colorbar, and overlays K-means."""
  # 2D Histogram counts
  counts, _, _ = np.histogram2d(
      x, y, bins=[bins_x, bins_y], range=[g_xlim, g_ylim]
  )

  # Convert counts to relative pseudo-free energy (in kJ/mol)
  dG = counts_to_free_energy(counts, kBT)

  # Extract the maximum sampled ΔG (ignoring NaN unvisited bins)
  condition_max_dG_kJ = float(np.nanmax(dG))
  condition_max_dG_kcal = condition_max_dG_kJ * KJ_TO_KCAL

  fig, ax = plt.subplots(figsize=(6.0, 4.8), dpi=300)

  # Plot 2D energy surface with linear coordinate bounds [0, max_dG_kJ]
  mesh = ax.pcolormesh(
      bins_x,
      bins_y,
      dG.T,
      cmap=custom_cmap,
      vmin=0.0,
      vmax=max_dG_kJ,
      shading="flat",
  )

  # -------------------------------------------------------------------------
  # LINEAR DUAL-SCALE COLORBAR
  # -------------------------------------------------------------------------
  cbar = fig.colorbar(mesh, ax=ax, pad=0.12)
  cbar.set_label(r"$\Delta G$ (kJ/mol)", fontsize=font_size_cbar_label)
  cbar.set_ticks(np.arange(0, max_dG_kJ + 1, 5))
  cbar.ax.tick_params(labelsize=font_size_ticks)

  # Attach linear secondary y-axis for kcal/mol
  sec_cbar = cbar.ax.secondary_yaxis(
      "left", functions=(lambda kj: kj * KJ_TO_KCAL, lambda kcal: kcal * 4.184)
  )
  sec_cbar.set_ylabel(r"$\Delta G$ (kcal/mol)", fontsize=font_size_cbar_label)
  sec_cbar.set_ticks(np.arange(0, int(max_dG_kJ * KJ_TO_KCAL) + 1, 1))
  sec_cbar.tick_params(labelsize=font_size_ticks)

  # Overlay K-means centroids
  for i in range(len(k_rmsd)):
    ax.scatter(
        k_rmsd[i],
        k_rg[i],
        color=kmeans_colors[i],
        edgecolors="black",
        linewidths=1.2,
        s=kmeans_marker_size,
        zorder=10,
        label=f"K-means Frame {i}",
    )

  # Axes boundaries, labels, and ticks
  ax.set_xlim(g_xlim)
  ax.set_ylim(g_ylim)
  ax.set_xlabel(x_label, fontsize=font_size_axes_labels)
  ax.set_ylabel(y_label, fontsize=font_size_axes_labels)
  ax.set_title(title, fontsize=font_size_title, fontweight="bold")
  ax.tick_params(axis="both", which="major", labelsize=font_size_ticks)

  # Position legend to the right of the dual colorbar
#  ax.legend(
#      bbox_to_anchor=(legend_x_offset, 1.0),
#      loc="upper left",
#      borderaxespad=0.0,
#      fontsize=font_size_legend,
#  )

  plt.tight_layout()
  plt.savefig(filename, dpi=300, bbox_inches="tight")
  plt.close()

  print(f"Saved: {filename}")
  print(
      f"  └─ Maximum ΔG for {title}: {condition_max_dG_kJ:.2f} kJ/mol"
      f" ({condition_max_dG_kcal:.2f} kcal/mol)"
  )

  return condition_max_dG_kJ


# ==============================================================================
# 4. RUN COMBINED ANALYSIS PER CONDITION
# ==============================================================================
overall_max_dG_kJ = 0.0

for p in prefixes:
  p_rmsd = []
  p_rg = []
  k_rmsd, k_rg = kmeans_data[p]

  # Aggregate all replicates for this condition
  for r in replicates:
    if (p, r) in all_data:
      rmsd, rg = all_data[(p, r)]
      p_rmsd.append(rmsd)
      p_rg.append(rg)

  # Compute and save single combined FES plot per condition
  if p_rmsd:
    combined_rmsd = np.concatenate(p_rmsd)
    combined_rg = np.concatenate(p_rg)

    cond_max = save_fes_with_kmeans(
        combined_rmsd,
        combined_rg,
        k_rmsd,
        k_rg,
        title=f"Pseudo-Free Energy Surface: {p} (Combined Replicates)",
        filename=f"fes_dual_{p}_combined_kmeans.png",
    )
    overall_max_dG_kJ = max(overall_max_dG_kJ, cond_max)

print(
    f"\nOverall Maximum sampled ΔG found across all conditions: "
    f"{overall_max_dG_kJ:.2f} kJ/mol ({overall_max_dG_kJ * KJ_TO_KCAL:.2f}"
    " kcal/mol)"
)
