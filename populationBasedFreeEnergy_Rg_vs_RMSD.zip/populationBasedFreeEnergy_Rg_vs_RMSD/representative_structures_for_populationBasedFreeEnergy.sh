#!/bin/bash
#SBATCH -J rep150mM30_analysis
#SBATCH -o rep150mM30_analysis.slurm.out
#SBATCH --mem=64G
#SBATCH --cpus-per-task=32
#SBATCH --time=06:00:00

conda activate ambertools
prefix="150mM30"
prmtop="/lab/mml/kipp/645div/nistmab/analysis/diffusion/unwrapped/aa_NISTmAb_${prefix}_r01_unwrapped.prmtop"
trajectory="/lab/mml/kipp/645div/nistmab/analysis/cluster/${prefix}_10us_every10_kmeans/comb_${prefix}_9kmeans.nc"

cpptraj << EOF
parm ${prmtop}
trajin ${trajectory}
radgyr :1-1343 out rg_${prefix}_9kmeans.dat
parm starting_fromibbrcluster.prmtop [reftop]
reference starting_fromibbrcluster.rst7 parm [reftop] [struct0]
rms allTR (:1-1343)&(@CA) ref [struct0] out rmsd_${prefix}_9kmeans.dat
run
EOF
