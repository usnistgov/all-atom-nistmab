import glob
import re
import numpy as np
import scipy.optimize as opt

# --- CONFIGURATION ---
DATATYPE = 'BufSubtract'
SEARCH_PATTERN = f'<exp data path>/*{DATATYPE.strip()}*.txt'
CLUSTER_PATTERN = "<sim data path>/*.txt"
Q_MIN, Q_MAX = 0.009, 0.019


# --- HELPER FUNCTIONS ---
def extract_concentration(key):
    return float(key.split('_')[1])


def extract_clust_number(filename):
    match = re.search(r"clust(\d+)", filename)
    return int(match.group(1)) if match else 0


def porod_fit(q, Iq, Ierr, q_min, q_max):
    mask = (q >= q_min) & (q <= q_max)
    q_fit = q[mask]
    Iq_fit = Iq[mask]
    Ierr_fit = Ierr[mask]
    q4 = q_fit**4
    Iq4 = Iq_fit * q4
    Iq4err = Iq4 * (Ierr_fit / Iq_fit)

    def porod_model(q, Bkg, C):
        return Bkg * q**4 + C

    popt, _ = opt.curve_fit(porod_model, q_fit, Iq4, sigma=Iq4err, absolute_sigma=True)
    return popt[0]


def load_cluster_data(filepath):
    with open(filepath, "r") as f:
        content = f.read()
    cleaned = re.sub(r"\\", "", content)
    cleaned = re.sub(r"<X>\s*<Y>", "", cleaned)
    floats = [float(x) for x in cleaned.split()]
    return np.array(floats[0::2]), np.array(floats[1::2])


def guinier_fit(q, Iq, Ierr, q_min, q_max):
    mask = (q >= q_min) & (q <= q_max)
    q_fit = q[mask]
    Iq_fit = Iq[mask]
    Ierr_fit = Ierr[mask]
    
    log_Iq = np.log(Iq_fit)
    log_Ierr = Ierr_fit / Iq_fit
    
    def guinier_model(q, ln_I0, Rg2_over_3):
        return ln_I0 - Rg2_over_3 * q**2
    
    popt, pcov = opt.curve_fit(guinier_model, q_fit, log_Iq, sigma=log_Ierr, absolute_sigma=True)
    perr = np.sqrt(np.diag(pcov))
    Rg = np.sqrt(3 * abs(popt[1]))
    Rg_err = (1 / (2 * Rg)) * (3 * perr[1]) if Rg > 0 else np.nan
    return Rg, Rg_err


# --- DATA LOADING & PROCESSING ---
alldata = {}
files = glob.glob(SEARCH_PATTERN)

for file in files:
    with open(file, 'r') as f:
        data = f.read()
    parts = file.split('-')
    name = parts[1].split('_')[0]
    
    rows = [row for row in data.splitlines() if not row.startswith('<') and row.strip()]
    q, Iq, IErr, _ = [list(x) for x in zip(*[map(float, row.split()) for row in rows if row.strip()])]

    alldata[f'q_{name}'] = np.array(q)
    alldata[f'Iq_{name}'] = np.array(Iq)
    alldata[f'IErr_{name}'] = np.array(IErr)

q_keys = sorted([key for key in alldata.keys() if key.startswith('q_')], key=extract_concentration)

# --- EXECUTE FITS AND COLIATE RESULTS ---
results_table = []

# 1. Process Experimental Data
for q_key in q_keys:
    label = q_key.split('_')[1]
    q = alldata[f'q_{label}']
    Iq = alldata[f'Iq_{label}']
    IErr = alldata[f'IErr_{label}']
    
    bkg = porod_fit(q, Iq, IErr, 0.2, 0.5)
    IqBkg = Iq - bkg
    IqBkgErr = np.sqrt(IErr**2 + (IErr * 0.01)**2)
    
    try:
        Rg, Rg_err = guinier_fit(q, IqBkg, IqBkgErr, Q_MIN, Q_MAX)
        results_table.append((f"Expt: {label} mg/mL", Rg, Rg_err))
    except Exception:
        results_table.append((f"Expt: {label} mg/mL", np.nan, np.nan))

# 2. Process Cluster Data
cluster_files = sorted(glob.glob(CLUSTER_PATTERN), key=extract_clust_number)
for c_file in cluster_files:
    c_num = extract_clust_number(c_file)
    c_x, c_y = load_cluster_data(c_file)
    c_y_err = c_y * 0.01
    
    try:
        Rg, Rg_err = guinier_fit(c_x, c_y, c_y_err, Q_MIN, Q_MAX)
        results_table.append((f"Cluster Fit {c_num}", Rg, Rg_err))
    except Exception:
        results_table.append((f"Cluster Fit {c_num}", np.nan, np.nan))

# --- PRINT SUMMARY TABLE ---
print(f"\n\033[1m{'Dataset / Source':<25} {'Rg (Å)':^12} {'Rg Error (Å)':^12}\033[0m")
print("-" * 53)
for name, rg, err in results_table:
    print(f"{name:<25} {rg:^12.3f} {err:^12.3f}")

# --- SAVE SUMMARY TABLE TO FILE ---
output_txt_filename = "150mM_guinier_results.txt" 

with open(output_txt_filename, "w", encoding="utf-8") as out_file:
    # Write the header without ANSI terminal color codes
    out_file.write(f"{'Dataset / Source':<25} {'Rg (Å)':^12} {'Rg Error (Å)':^12}\n")
    out_file.write("-" * 53 + "\n")
    
    # Write each row
    for name, rg, err in results_table:
        out_file.write(f"{name:<25} {rg:^12.3f} {err:^12.3f}\n")

print(f"Summary table successfully saved to: {output_txt_filename}")
