import glob
import re
import matplotlib.cm as cm
import matplotlib.pyplot as plt
import numpy as np
import scipy.optimize as opt

# --- CONFIGURATION ---
TITLE = r"NISTmAb, 1.25 mg/mL (pH 6) vs Scaled Cluster Models"
DATATYPE = "BufSubtract"
SEARCH_PATTERN = f"<exp_data_path>/*{DATATYPE.strip()}*.txt"
CLUSTER_PATTERN = "<sim_data_path>/*.txt"
RNG_MIN = 7e-3    # Lower bound for average scaling alignment
RNG_MAX = 9e-3    # Upper bound for average scaling alignment
ALIGN_X = 8e-4    # q coordinate for mutual cluster alignment


# --- HELPER FUNCTIONS ---
def extract_clust_number(filename):
    """Extracts the digit from the cluster filename for sorting."""
    match = re.search(r"clust(\d+)", filename)
    return int(match.group(1)) if match else 0


def porod_fit(q, Iq, Ierr, q_min, q_max):
    """Fits Porod model: I(q) = Bkg + C/q^4."""
    mask = (q >= q_min) & (q <= q_max)
    q_fit = q[mask]
    Iq_fit = Iq[mask]
    Ierr_fit = Ierr[mask]

    q4 = q_fit**4
    Iq4 = Iq_fit * q4
    Iq4err = Iq4 * (Ierr_fit / Iq_fit)

    def porod_model(q, Bkg, C):
        return Bkg * q**4 + C

    popt, _ = opt.curve_fit(
        porod_model, q_fit, Iq4, sigma=Iq4err, absolute_sigma=True
    )
    return popt[0]  # Returns Background (Bkg)


def load_cluster_data(filepath):
    """Parses cluster .txt data, stripping source blocks safely."""
    with open(filepath, "r") as f:
        content = f.read()
    cleaned = re.sub(r"\\", "", content)
    cleaned = re.sub(r"<X>\s*<Y>", "", cleaned)
    floats = [float(x) for x in cleaned.split()]
    return np.array(floats[0::2]), np.array(floats[1::2])


# --- DATA LOADING & PROCESSING ---
# 1. Load the 1.25 mg/mL experimental dataset
files = glob.glob(SEARCH_PATTERN)
q_125, Iq_125, IErr_125 = None, None, None

for file in files:
    parts = file.split("-")
    name = parts[1].split("_")[0]
    if name == "1.25":
        with open(file, "r") as f:
            data = f.read()
        rows = [
            r
            for r in data.splitlines()
            if not r.startswith("<") and r.strip()
        ]
        q, Iq, IErr, _ = [
            list(x)
            for x in zip(
                *[map(float, row.split()) for row in rows if row.strip()]
            )
        ]
        q_125, Iq_125, IErr_125 = np.array(q), np.array(Iq), np.array(IErr)
        break

if q_125 is None:
    raise FileNotFoundError(
        "Could not find the 1.25 mg/mL experimental data file."
    )

# 2. Subtract background using Porod fit
bkg_125 = porod_fit(q_125, Iq_125, IErr_125, q_min=0.2, q_max=0.5)
IqBkg_125 = Iq_125 - bkg_125

# 3. Determine experimental intensity average between 7e-3 and 9e-3
align_mask = (q_125 >= RNG_MIN) & (q_125 <= RNG_MAX)
q_align_range = q_125[align_mask]
target_y_val = np.mean(IqBkg_125[align_mask])

# 4. Discover and sort the 9 cluster files
cluster_files = sorted(glob.glob(CLUSTER_PATTERN), key=extract_clust_number)

# 5. Load and pre-align cluster curves mutually at ALIGN_X (8e-4)
cluster_data = []
c_y_at_target_list = []

for c_file in cluster_files:
    c_x, c_y = load_cluster_data(c_file)
    c_y_at_align = np.interp(ALIGN_X, c_x, c_y)
    c_y_pre_scaled = c_y / c_y_at_align  # All equal 1.0 at ALIGN_X
    
    # Evaluate pre-scaled average value over the target range
    c_y_interp = np.interp(q_align_range, c_x, c_y_pre_scaled)
    c_y_at_target = np.mean(c_y_interp)
    c_y_at_target_list.append(c_y_at_target)
    cluster_data.append((c_x, c_y_pre_scaled, c_file))

# 6. Calculate global scale factor based on the cluster average at target range
avg_c_y_at_target = np.mean(c_y_at_target_list)
global_scale_factor = target_y_val / avg_c_y_at_target


# --- PLOTTING INDIVIDUAL PLOTS ---
colors = ["black", "red", "green", "blue", "orange", "brown", "grey", "violet", "cyan"]
mask = q_125 >= 0.003

for i, (c_x, c_y_pre_scaled, c_file) in enumerate(cluster_data):
    fig, ax = plt.subplots(figsize=(7, 5))
    
    # Plot experimental background-subtracted 1.25 mg/mL curve
    ax.errorbar(
        q_125[mask] * 10,#0.1,
        IqBkg_125[mask],
        yerr=IErr_125[mask],
        fmt="none",
        ecolor="black",
        elinewidth=1.5,
        capsize=0,
        zorder=2,
    )
    ax.scatter(
        q_125[mask] * 10,#0.1,
        IqBkg_125[mask],
        color="black",
        alpha=0.4,
        edgecolor="black",
        zorder=3,
        label="Expt: 1.50 mg/mL",
        s=50,
        linewidths=1.5,
    )

    # Scale and plot specific cluster
    c_y_scaled = c_y_pre_scaled * global_scale_factor
    c_label = f"Cluster {i}"
    
    ax.plot(
        c_x * 10,#0.1,
        c_y_scaled,
        color=colors[i],
        linestyle="-",
        linewidth=3.5,
        label=c_label,
        zorder=4,
    )

    # Axis formatting and labeling
#    ax.grid(True, which="both", linestyle=":", linewidth=2, color="gray", alpha=0.3)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel(r"Q  [nm$^{-1}$]", fontsize=20, labelpad=10)
    ax.set_ylabel(r"I(Q)  [arb. units]", fontsize=20, labelpad=10)
    ax.tick_params(axis="both", which="major", labelsize=18, length=8, width=2)
    ax.tick_params(axis="both", which="minor", length=4, width=1.5)

    for spine in ax.spines.values():
        spine.set_linewidth(2)
    ax.legend(fontsize=18, loc="lower left")#best")

    # Layout constraints matching original top plot
    ax.set_ylim([5e-5, .25])#[1e-5, .3])
    ax.set_xlim(3.5e-2, 3.7)#0.037)#0.55)
#    ax.set_title(
#        f"I(Q) - Bkg vs Scaled Cluster {i} (Log-Log)",
#        fontsize=24,
#        fontweight="bold",
#        pad=20,
#    )

    fig.tight_layout()
    plt.savefig(f"{i}_plot.png", dpi=300)
    plt.close(fig)
